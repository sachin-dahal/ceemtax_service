package com.example.ceemtax_service

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
